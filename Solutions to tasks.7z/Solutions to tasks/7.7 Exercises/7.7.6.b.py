L = []
for i in range(1,51):
	L.append(i)
M = []
for i in range(len(L)):
	M.append(L[i]**2)
print(M) 