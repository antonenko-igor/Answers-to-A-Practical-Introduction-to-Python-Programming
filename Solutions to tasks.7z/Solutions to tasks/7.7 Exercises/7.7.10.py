L = eval(input("Enter a list:  "))
print("The modified list - ",L[-1:]+L[:-1]) 