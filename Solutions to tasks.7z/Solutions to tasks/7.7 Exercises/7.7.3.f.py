L = [8,9,10]
L[1] = 17
L.append(4)
L.append(5)
L.append(6)
del L[0]
L.sort()
M = L*2
M.insert(3,25)
print(M)  