L = [8,9,10]
L[1] = 17
print(L) 