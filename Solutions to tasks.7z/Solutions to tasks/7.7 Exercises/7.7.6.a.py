L = []
for i in range(0,50):
	L.append(i)
print(L) 