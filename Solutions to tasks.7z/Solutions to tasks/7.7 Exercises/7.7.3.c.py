L = [8,9,10]
L.append(4)
L.append(5)
L.append(6)
del L[0]
print(L) 