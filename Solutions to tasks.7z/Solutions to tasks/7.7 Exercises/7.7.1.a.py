L = eval(input("Enter a list of integers:  "))
print(len(L)) 