L = ["red","blue","green"]
M = [len(i) for i in L]
print(M)  