L = ["red","blue","green"]
M = [i[1:] for i in L]
print(M) 