from random import randint
L = []
for i in range(6):
	L.append(randint(1,48))
print(L) 