L = [1, *[j for i in range(11) for j in [*[0 for k in range(i)],1]]]	
print(L)	
