string = input("Enter a sentence:  ")

L = string.split()
print(L[2]) 