string = input("Enter five numbers:  ")

L = string.split()
l = "+".join(L)
print(l) 