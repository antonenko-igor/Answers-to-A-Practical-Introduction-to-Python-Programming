from random import choice

L = ["Success comes to those who act.","Don't stop yet\
you won't be proud.","Dreams won't work until you do."]
l = choice(L)
print(l) 