L = ["I","he","she","it","we","you","they"]
M = [i for i in L if len(i)>=3]
print(M) 