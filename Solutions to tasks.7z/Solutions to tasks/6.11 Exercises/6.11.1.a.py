string = input("Enter a string:  ")
print(" The total number of characters in the string - ",len(string)) 