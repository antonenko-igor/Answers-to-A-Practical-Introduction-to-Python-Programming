s = input("Enter a word that contains the letter a.:  ")

for i in s:	
	if i != "a":
		print(i,end="")
	else:
		print(i) 