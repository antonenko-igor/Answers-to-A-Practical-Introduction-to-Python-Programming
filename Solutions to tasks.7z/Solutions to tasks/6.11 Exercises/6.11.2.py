strings = input("Enter a string of words:  ")
x = 1
for i in strings:
	if i == " ":
		x = x + 1
print(x) 		