s = input("Enter their name: ")
s1 = " "
for i in s:
	if i !=" ":
		s1 = s1 +i
	if i == " ":
		print("Dear",s,",")
		print()
		print(
"I am pleased to offer you our new Platinum Plus Rewards card at a special" 
" introductory APR of 47.99%.",s1,", an offer like this does not come along every" 
" day, so I urge you to call now toll-free at  1-800-314-1592. We cannot offer"
" such a low rate for long,", s1,", so call right away.")  