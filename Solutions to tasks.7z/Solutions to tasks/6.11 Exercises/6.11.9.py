num = eval(input("Enter a number:  "))
s = " "

for i in range(1,num + 1):
	print(s + str(i))
	s = s + "  " 