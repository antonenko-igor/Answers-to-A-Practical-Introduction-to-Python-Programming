string = input("Enter a string:  ")
print(string[0:3]) 