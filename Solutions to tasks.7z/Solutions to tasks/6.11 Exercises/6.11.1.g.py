string = input("Enter a string:  ")

if len(string) >= 7:
	print(string[6])
else:
	print("The string length is less than 7 characters.") 