string = input ("Enter a string:  ")

s_doubled = " "
for c in string:
	s_doubled =  c * 2
	print(s_doubled) 