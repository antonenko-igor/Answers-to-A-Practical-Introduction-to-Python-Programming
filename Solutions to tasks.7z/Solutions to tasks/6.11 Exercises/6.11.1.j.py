string = input("Enter string:  ")
print(string.replace("a","e")) 