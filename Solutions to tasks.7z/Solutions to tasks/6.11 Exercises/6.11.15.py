s1 = input("Enter a college class:  ")
s2 = input("Enter an adjective:  ")
s3 = input("Enter an activity:  ")

print(s1,"class was really",s2 ,"today."\
"We learned how to",s3 ," today in class. I can't wait for tomorrow's class!") 