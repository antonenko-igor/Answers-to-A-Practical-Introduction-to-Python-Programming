string = input("Enter string:   ")
print(string[1:(len(string)-1)]) 