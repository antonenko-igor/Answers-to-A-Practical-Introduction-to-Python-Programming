string = input("Enter a string:  ")
print(string[: :-1])  