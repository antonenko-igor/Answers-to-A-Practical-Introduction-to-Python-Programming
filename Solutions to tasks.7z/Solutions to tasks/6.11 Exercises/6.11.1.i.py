string = input("Enter string:  ")
print(string.upper()) 