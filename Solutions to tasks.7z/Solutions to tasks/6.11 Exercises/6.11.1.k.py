string = input("Enter string:  ")
print(s.replace(string[ : ]," ")) 