p = eval(input("Enter a power x^"))
print("The derivative x ^" ,p, "is ",p,"x ^ ",p-1 ) 