num = eval(input("Enter a number:  "))
for x in range(1,1000):
	for y in range(1,1000):
		if x**2 - y**2 == num:
			print("x=",x,"y=",y) 