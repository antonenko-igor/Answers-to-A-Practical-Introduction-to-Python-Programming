weight = eval(input("Enter a weight(kilogram) - "))
print("{:.1f}".format(weight)) 