L = []
c = "1"
for i in range(101):
	c = c + '1'
	L.append(int(c))
print(L) 