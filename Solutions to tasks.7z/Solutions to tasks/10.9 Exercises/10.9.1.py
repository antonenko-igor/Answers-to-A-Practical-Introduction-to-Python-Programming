L = list(range(3,100,3))
print(L) 