for x in range(0,101):
	for y in range(0,101):
		z = 100 - x - y
		if 5*x + 3*y + (1/3)*z == 100:
			print("Starfruits",x,"  Mangoes", y,"  Oranges", z) 