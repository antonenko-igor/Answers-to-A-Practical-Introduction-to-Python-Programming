from random import randint

name = input("Enter your name - ")
x = randint(1,10)
for i in range(x):
	print(name) 