from math import cos, sin, tan

num = eval(input("Enter a number: "))
print("sin", num,"=",sin(num))
print("cos",num,"=",cos(num))
print("tan",num,"=",tan(num)) 