from random import uniform

x = round(uniform(1,10), 2)
print(x) 