from random import randint
x = randint(1,50)
y = randint(2,5)
print(x**y) 