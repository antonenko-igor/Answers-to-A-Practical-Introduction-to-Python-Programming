x = eval(input("Enter an angle between -180 and 180 degrees -"))
print("Its equivalent between 0 and 360 degree is ",(180-x)%360) 