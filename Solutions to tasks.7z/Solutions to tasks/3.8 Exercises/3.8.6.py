x = eval(input("Enter the first number -"))
y = eval(input("Enter the second number -"))
print(abs(x-y)/(x+y)) 