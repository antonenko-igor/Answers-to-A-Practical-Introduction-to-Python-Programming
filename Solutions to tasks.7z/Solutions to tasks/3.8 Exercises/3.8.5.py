from random import randint
for i in range(1,51):
	x = randint(1,(i+1))
	print(i, "-", x) 