from math import *

for i in range(0, 346, 15):
	print(i," --- ",round(sin(radians(i)),4),"   ",round(cos(radians(i)),4)) 	