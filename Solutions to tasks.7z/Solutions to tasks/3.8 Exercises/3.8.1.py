from random import randint

for i in range(1,51):
	x = randint(3,6)
	print(i,".", x) 