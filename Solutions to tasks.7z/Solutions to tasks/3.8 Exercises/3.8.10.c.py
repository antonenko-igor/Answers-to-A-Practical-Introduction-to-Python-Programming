power = eval(input("Enter a power: "))
digits = eval(input("How many the last digits are?:  "))

print((2**power)%(10**digits)) 