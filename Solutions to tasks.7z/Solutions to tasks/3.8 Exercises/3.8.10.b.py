power = eval(input("Enter a power: "))
print("The last two digits are ",(2**power)%100) 