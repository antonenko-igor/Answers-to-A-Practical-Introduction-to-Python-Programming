x = eval(input("Enter a power: "))
print("The last digit is ",(2**x)%10) 