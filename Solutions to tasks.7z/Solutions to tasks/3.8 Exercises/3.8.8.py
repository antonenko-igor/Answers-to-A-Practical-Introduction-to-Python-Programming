sec = eval(input("Enter a number of seconds:  "))
print( sec//60, "min", sec%60,"sec") 
