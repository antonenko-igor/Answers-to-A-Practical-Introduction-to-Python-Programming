from math import factorial

num = eval(input("Enter a number: "))
print("The factorial of the number is - ",factorial(num)) 