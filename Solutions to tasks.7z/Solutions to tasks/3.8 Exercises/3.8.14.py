from math import *

angle = eval(input("Enter an angle in degrees: "))
print("sin", angle, "=",sin(radians(angle))) 