weight = eval(input("Enter a weight in kg: "))
print("The weight in pounds is - ",round((weight*2.2),1)) 