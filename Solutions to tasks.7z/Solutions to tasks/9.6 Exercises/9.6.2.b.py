string = "abracadabra"
i = 1

while i < len(string):	
	print(string[i], end = " ")
	i = i + 2 