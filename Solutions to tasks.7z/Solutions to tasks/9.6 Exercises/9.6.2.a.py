string = "abracadabra"
i = 0

while i < len(string):    
    print(string[i])
    i = i + 1  