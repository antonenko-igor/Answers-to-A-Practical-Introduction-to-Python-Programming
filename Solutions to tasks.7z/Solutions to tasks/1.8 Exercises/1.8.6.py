x = eval(input("Enter a number: "))
print(x ,2*x ,3*x ,4*x ,5*x , sep='---') 