x = eval(input("Enter a number: "))
print("The square of the number  ",  x,  " is ",  x*x,". ", sep='') 
