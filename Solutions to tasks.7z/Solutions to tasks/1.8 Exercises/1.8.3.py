print("*")
print("**")
print("***")
print("****") 