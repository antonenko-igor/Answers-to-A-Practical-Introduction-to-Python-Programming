x = eval(input("Enter a weight in kg: "))
print("The weight in pounds is : ", x*2.2) 