p = eval(input("Enter the price of the meal: "))
t = eval(input("Enter the percent tip: "))
x =(p*t)/100
print("The tip amount: ", x)
print("Total bill: ",x + p) 