name = input("Enter your name - ")
for i in range(100):
	print(i+1,name) 