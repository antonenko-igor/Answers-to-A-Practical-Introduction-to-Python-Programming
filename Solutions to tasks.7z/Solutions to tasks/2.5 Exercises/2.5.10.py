length = eval(input("How wide is a box?: "))
height = eval(input("How high is a box?: "))
for i in range(height):
	print(" * " *length) 	