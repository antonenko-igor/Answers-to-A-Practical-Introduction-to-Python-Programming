name = input("Enter your name - ")
for i in range(100):
	print(name) 