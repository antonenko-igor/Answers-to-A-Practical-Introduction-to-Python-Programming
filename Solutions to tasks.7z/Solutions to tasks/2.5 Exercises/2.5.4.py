for i in range(1,21):
	print(i, "---",i*i) 