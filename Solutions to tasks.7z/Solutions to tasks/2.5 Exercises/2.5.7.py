for i in range(10):
	print("A", end="")
for i in range(7):
	print("B", end="")
for i in range(4):
	print("C", end="")
	print("D", end="")
print("E", end="")
for i in range(6):
	print("F", end="")
print("G", end="") 