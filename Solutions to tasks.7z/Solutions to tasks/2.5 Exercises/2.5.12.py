x = eval(input("How high is a triangle?:   "))
for i in range(x):
	print("* "*(i+1))  