name = input("Enter your name - ")
x = eval(input("How many times: "))
for i in range(x):
	print(name) 