num = eval(input("Enter an integer - "))
f = 1
for i in range(1,num+1):
	f = f * i 
print("The factorial of the integer - ",num," is ",f) 