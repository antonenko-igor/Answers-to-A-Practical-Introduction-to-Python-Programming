s = 0
for i in range(10):
	score = (eval(input("Enter a test score: ")))
	s = s + score
print("The average of the scores - ",s/10) 