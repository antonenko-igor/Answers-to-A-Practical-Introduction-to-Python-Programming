x = eval(input("Enter a value of x: "))
y = eval(input("Enter a value of y: "))
z = eval(input("Enter a value of z: "))

x,y,z = y,z,x
print("x = ", x, " y = ", y, " z = ", z) 