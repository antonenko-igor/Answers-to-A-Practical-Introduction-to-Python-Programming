count = 0
for i in range(1,2001):
	if i % 2 == 0:
		count = count - i
	else:
	    count = count + i
print(count)	    	