length = eval(input("Enter a length in cm:  "))
if length > 0:
	print("The length in inches is: ",length*2.54)
else:
	print("The entry is invalid!") 