x = 200
for i in range(x):
    if i % 5 == 2:
       if i % 6 == 3:
          if i % 7 == 2:
             print(i, 'pieces.') 