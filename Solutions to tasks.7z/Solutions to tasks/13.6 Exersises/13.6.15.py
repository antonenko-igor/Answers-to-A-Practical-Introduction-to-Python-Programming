def root(x,n=2):
	a = x ** (1/n)
	return a 
print(root(5,4)) 