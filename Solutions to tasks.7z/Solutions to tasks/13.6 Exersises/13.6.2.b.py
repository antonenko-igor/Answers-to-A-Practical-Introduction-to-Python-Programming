def add_exitement(L):
	M = []
	for i in range(len(L)):
		M.append(L[i] + "!")
	return M 
print(add_exitement(["I learn English","I do it"])) 