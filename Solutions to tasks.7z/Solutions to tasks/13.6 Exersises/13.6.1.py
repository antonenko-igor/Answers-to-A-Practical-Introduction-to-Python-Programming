def rectangle(n,m):
	for i in range(n):
		print(" * "*m)
rectangle(2,4) 