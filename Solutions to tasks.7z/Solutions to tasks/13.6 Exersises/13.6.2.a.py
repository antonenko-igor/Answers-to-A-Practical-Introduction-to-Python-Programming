def add_excitement(L):
	print([s +"!" for s in L])
	
add_excitement(["I learn English","I do it"]) 