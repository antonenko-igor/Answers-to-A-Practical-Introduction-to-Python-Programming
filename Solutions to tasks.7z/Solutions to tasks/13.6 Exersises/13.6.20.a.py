def merge(L1,L2):
	L = L1 + L2
	L.sort()
	return L
print(merge([5,6,7,8,9], [1,2,3])) 